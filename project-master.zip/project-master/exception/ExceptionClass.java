package exception;
import main.MobileMain;
public class ExceptionClass extends Exception{

	public 	ExceptionClass(String exp)
	{
		 
	}
		
}
