package service;

public interface Service {

		void purchase();
		void search(String mobile);
		void display();
		
}