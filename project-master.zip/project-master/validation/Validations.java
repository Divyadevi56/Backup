package validation;

import java.util.regex.Pattern;

public class Validations {

	Pattern p=Pattern.compile("[A_Z][0-9]{,4}");
	
		
}
