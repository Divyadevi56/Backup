package main;

import service.Service;
import service.ServiceImpl;

public class MobileMain extends ServiceImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Service sI=new ServiceImpl();
		sI.display();

	}

}
