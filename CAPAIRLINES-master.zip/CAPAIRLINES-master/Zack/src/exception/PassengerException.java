package exception;

public class PassengerException extends Exception{

	public PassengerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}