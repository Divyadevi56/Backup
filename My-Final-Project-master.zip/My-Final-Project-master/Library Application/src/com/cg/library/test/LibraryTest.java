package com.cg.library.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.library.bean.LibraryBean;

public class LibraryTest 
{
	
	@Test
	public void test() 
	{
		LibraryBean libraryBean = new LibraryBean();
		
		fail("Not yet implemented");
	}

}
