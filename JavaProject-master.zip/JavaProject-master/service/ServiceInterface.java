package service;

public interface ServiceInterface {
		
	void addEmployee();
	void addproject();
	void assignProject();
	void removeProject();
	
	
	
}
