package exception;

public class FlightException extends Exception{

	public FlightException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
