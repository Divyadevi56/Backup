package com.cg.babycare.exception;

public class BabyCareException extends Exception
{   private static final long serialVersionUID = 726264577455921591L;
public BabyCareException(String message) 
{
	super(message);
}

}
