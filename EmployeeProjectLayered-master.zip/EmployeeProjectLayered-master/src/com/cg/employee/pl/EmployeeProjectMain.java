package com.cg.employee.pl;

import java.util.Scanner;

public class EmployeeProjectMain {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
	}
	
}
