package com.cg.employee.exception;

public class ProjectException extends Exception{

	public ProjectException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
