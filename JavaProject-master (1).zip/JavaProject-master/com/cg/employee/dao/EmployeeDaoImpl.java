package com.cg.employee.dao;

import com.cg.employee.bean.EmployeeBean;
import com.cg.employee.bean.ProjectBean;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.exception.ProjectException;

public class EmployeeDaoImpl implements IEmployeeDao{

	@Override
	public String addProject(ProjectBean project) throws ProjectException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeProject(ProjectBean project) throws ProjectException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ProjectBean viewProject(String projectId) throws ProjectException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addEmployee(EmployeeBean employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeEmployee(EmployeeBean emplBean) throws EmployeeException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EmployeeBean viewEmployeeDetails(String empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
